﻿using System;
using SimioAPI;
//using SimioAPI.Extensions;
//using Simio;
//using System.Collections.Generic;
//using System.Linq;
//using System.Web;
using System.IO;

namespace ConsoleApp2
{
    public class SIMIO
    {
        ISimioProject currentProject;
        IModel currentModel;
        IExperiment currentExperiment;


        public void SetProject(string project, string model, string experiment)
        {
            // Set extension folder path
            SimioProjectFactory.SetExtensionsPath(Directory.GetCurrentDirectory().ToString());
            //SimioProjectFactory.SetExtensionsPath("C:/Users/jjk24/source/repos/ConsoleApp2/ConsoleApp2/bin/Debug/netcoreapp3.1");
            // Open project
            string[] warnings;
            currentProject = SimioProjectFactory.LoadProject(project, out warnings);
            if (model != null || model != "")
            {
                SetModel(model);
                SetExperiment(experiment);

            }

        }

        public void SetModel(string model)
        {
            if (currentProject != null)
            {
                currentModel = currentProject.Models[model];
                
            }
           
        }

        public void SetExperiment(string experiment)
        {
            currentExperiment = currentModel.Experiments[experiment];
        }


        public ISimioProject GetCurrentProject()
        {
            return currentProject;
        }
    }


    class Program
    {

        static void Main(string[] args)
        {

            SIMIO s = new SIMIO();


           Console.WriteLine("Enter Simio Project Name:");
           string SimioModel = Console.ReadLine();


            
            Console.Read();
            s.SetProject(SimioModel, "Model", "Experiment1"); //Final


        }


    }


}

    


   
    

